public class Lab5_Problem4_SORTEDLIST_DRIVER {
    public static void main(String[] args){
        SortedList ary = new SortedList();

        ary.add(5);
        System.out.println(ary.get(0));
        System.out.println(ary.size());
        ary.add(15);
        System.out.println(ary.get(1));
        System.out.println(ary.size());
    }
}
